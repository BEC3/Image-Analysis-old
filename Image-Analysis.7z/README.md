<h3>HOW TO USE ON LAB COMPUTER</h3>
<ul>
<li>open cmd</li>
<li>cd C:\ExperimentImages\Image-Analysis\imageAnalyze</li>
<li>python ImageUI.pyw</li>
<li></li>>Change "Image Folder Path" to "C:\\ExperimentImages\\"</li>
</ul>

<hr> 

<h5>1.0 version</h5>

<hr>
<h3>Next to do</h3>
<ul>
<li>AOI using mouse to choose area</li>
<li>Change saved data structure for either fitting use.</li>
<li>List of previous Image</li>
<li>Deal with Angle</li>
</ul>
